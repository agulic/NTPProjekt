//---------------------------------------------------------------------------

#ifndef DBH
#define DBH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
//---------------------------------------------------------------------------
class TDMServer : public TDataModule
{
__published:	// IDE-managed Components
	TADOConnection *ADOBazaPodataka;
	TADOTable *ADOLige;
	TADOTable *ADOCijena;
	TDataSource *DSLige;
	TDataSource *DSCijena;
	TAutoIncField *ADOLigeID;
	TWideStringField *ADOLigeLiga;
	TAutoIncField *ADOCijenaID;
	TIntegerField *ADOCijenaIDLige;
	TWideStringField *ADOCijenaImeUsluge;
	TBCDField *ADOCijenaCijenaUsluge;
private:	// User declarations
public:		// User declarations
	__fastcall TDMServer(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDMServer *DMServer;
//---------------------------------------------------------------------------
#endif
