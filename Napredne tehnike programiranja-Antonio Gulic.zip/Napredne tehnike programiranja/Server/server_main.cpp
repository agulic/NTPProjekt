//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "server_main.h"
#include "DB.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TCPServerExecute(TIdContext *AContext)
{
    TLocateOptions Opts;
	Opts.Clear();
	Opts << loCaseInsensitive;

	int ligaDuz = AContext->Connection->Socket->ReadInt32();
	String liga = AContext->Connection->Socket->ReadString(ligaDuz);
	int DuznostDuz = AContext->Connection->Socket->ReadInt32();
	String ObavljenaDuznost = AContext->Connection->Socket->ReadString(DuznostDuz);

	Edit1->Text = liga;
	Edit2->Text = ObavljenaDuznost;


	 if(DMServer->ADOLige->Locate("Liga", liga, Opts) == true)
	{
		int LigaID = DMServer->ADOLige->FieldByName("ID")->AsInteger;
		DMServer->ADOCijena->Filter = "IDLige LIKE " + QuotedStr(LigaID);
		DMServer->ADOCijena->Filtered = TRUE;

        Opts.Clear();
		Opts << loCaseInsensitive;

		if(DMServer->ADOCijena->Locate("ImeUsluge", ObavljenaDuznost, Opts) == true)
		{
			Edit3->Text = DMServer->ADOCijena->FieldByName("CijenaUsluge")->Text;
			AContext->Connection->Socket->Write(Edit3->Text.ToInt());
		}
	}

    AContext->Connection->Disconnect();

}
//---------------------------------------------------------------------------
