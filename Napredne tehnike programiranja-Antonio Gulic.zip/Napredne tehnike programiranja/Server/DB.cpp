//---------------------------------------------------------------------------


#pragma hdrstop

#include "DB.h"
#include "server_main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma classgroup "Vcl.Controls.TControl"
#pragma resource "*.dfm"
TDMServer *DMServer;
//---------------------------------------------------------------------------
__fastcall TDMServer::TDMServer(TComponent* Owner)
	: TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
