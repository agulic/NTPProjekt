//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainKlubovi.h"
#include "DBForm.h"
#include "Login.h"
#include <Registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "frxClass"
#pragma link "frxDBSet"
#pragma link "frxExportBaseDialog"
#pragma link "frxExportImage"
#pragma link "frxExportPDF"
#pragma link "frxExportRTF"
#pragma resource "*.dfm"
TFMainKlubovi *FMainKlubovi;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i = 0; i < Form->ComponentCount; i++) // iterate though all components on the form
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first) // find component by name
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language) // find translation for the target language
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}

//---------------------------------------------------------------------------
__fastcall TFMainKlubovi::TFMainKlubovi(TComponent* Owner)
	: TForm(Owner)
{
	translation["BUcitaj"] =	{
		{
			{"EN", "Load"},
			{"HR", "U�itaj"}
		}
	};
	translation["BBack"] =	{
		{
			{"EN", "Back to login"},
			{"HR", "Nazad na prijavu"}
		}
	};
	translation["BGeneriraj"] =	{
		{
			{"EN", "Generate warrant"},
			{"HR", "Generiraj nalog"}
		}
	};
	translation["DBGrid1.Column[0]"] =	{
		{
			{"EN", "ClubID"},
			{"HR", "IDKluba"}
		}
	};
	translation["CBBackground"] =	{
		{
			{"EN", "Dark Mode"},
			{"HR", "Tamni Na�in"}
		}
	};
	translation["Label3"] =	{
		{
			{"EN", "Font size:"},
			{"HR", "Veli�ina fonta:"}
		}
	};
	translation["CBFilter"] =	{
		{
			{"EN", "Filter"},
			{"HR", "Filtriraj"}
		}
	};
}
//---------------------------------------------------------------------------


void __fastcall TFMainKlubovi::BUcitajClick(TObject *Sender)
{
	DMBaza->ADOGotoviZapisnici->Filter = "ImeKluba LIKE " + QuotedStr(DMBaza->ADOKlubovi->FieldByName("Naziv")->Text + "%");
	DMBaza->ADOGotoviZapisnici->Filtered = TRUE;
	DBGrid1->Visible = TRUE;
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::BBackClick(TObject *Sender)
{
	   DMBaza->ADOGotoviZapisnici->Filtered = FALSE;
	   FMainKlubovi->Close();
	   FLogin->Show();
	   DBGrid1->Visible = FALSE;
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::FormClose(TObject *Sender, TCloseAction &Action)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	ini->WriteInteger("Main Window", "Left", Left);
	ini->WriteInteger("Main Window", "Top", Top);
	ini->WriteInteger("Main Window", "Width", Width);
	ini->WriteInteger("Main Window", "Height", Height);
	if (CBBackground->Checked)
		ini->WriteBool("Main Window", "Dark mode", TRUE);
	else
		ini->WriteBool("Main Window", "Dark mode", FALSE);

	ini->WriteString("Main Window", "Font size", EFont->Text);

	if(RBENG->Checked)
		ini->WriteString("Main Window", "Language", "ENG");
	else
        ini->WriteString("Main Window", "Language", "HR");
    delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::FormCreate(TObject *Sender)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	Left = ini->ReadInteger("Main Window", "Left", 0);
	Top = ini->ReadInteger("Main Window", "Top", 0);
	Width = ini->ReadInteger("Main Window", "Width", 800);
	Height = ini->ReadInteger("Main Window", "Height", 500);
	if(ini->ReadBool("Main Window", "Dark mode", FALSE))
		CBBackground->Checked = TRUE;
	else
		CBBackground->Checked = FALSE;

	String temp = ini->ReadString("Main Window", "Font size", 12);
	EFont->Text = temp;
    FMainKlubovi->Font->Size = EFont->Text.ToInt();

	if(ini->ReadString("Main Window", "Language","ENG") == "ENG")
		RBENG->Checked = TRUE;
	else
        RBHR->Checked = TRUE;
	delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::CBBackgroundClick(TObject *Sender)
{
	 if(CBBackground->Checked){
		FMainKlubovi->Color = clGray;

	 }
	 else{
		  FMainKlubovi->Color = clBtnFace;
	 }
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::EFontChange(TObject *Sender)
{
    FMainKlubovi->Font->Size = EFont->Text.ToInt();
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::RBENGClick(TObject *Sender)
{
    translateForm(this, "EN", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::RBHRClick(TObject *Sender)
{
	translateForm(this, "HR", translation);
}
//---------------------------------------------------------------------------


void __fastcall TFMainKlubovi::BGenerirajClick(TObject *Sender)
{
    FRMainKlubovi->ShowReport();
}
//---------------------------------------------------------------------------

void __fastcall TFMainKlubovi::CBFilterClick(TObject *Sender)
{
    if(CBFilter->Checked && !DTFilter>Text.IsEmpty())
	{
		DMBaza->ADOGotoviZapisnici->Filter = "Datum LIKE " + QuotedStr(DTFilter->Date);
	}
	DMBaza->ADOSluzbeneOsobe->Filtered = CBFilter->Checked;
}
//---------------------------------------------------------------------------

