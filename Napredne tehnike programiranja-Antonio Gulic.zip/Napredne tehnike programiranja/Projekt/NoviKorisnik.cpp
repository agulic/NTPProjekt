//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NoviKorisnik.h"
#include "DBForm.h"
#include <Registry.hpp>
#include "Login.h"
#include <jpeg.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Hash"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
TFNoviKorisnik *FNoviKorisnik;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i = 0; i < Form->ComponentCount; i++) // iterate though all components on the form
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first) // find component by name
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language) // find translation for the target language
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}

//---------------------------------------------------------------------------
__fastcall TFNoviKorisnik::TFNoviKorisnik(TComponent* Owner)
	: TForm(Owner)
{
		translation["Label1"] =	{
		{
			{"EN", "Username:"},
			{"HR", "Korsini�ko ime:"}
		}
	};
		translation["Label2"] =	{
		{
			{"EN", "Password:"},
			{"HR", "Lozinka:"}
		}
	};
		translation["Label4"] =	{
		{
			{"EN", "Last name:"},
			{"HR", "Prezime:"}
		}
	};
		translation["Label3"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Ime:"}
		}
	};
		translation["Label9"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Naziv:"}
		}
	};
		translation["Label10"] =	{
		{
			{"EN", "Adress:"},
			{"HR", "Adresa:"}
		}
	};

		translation["Label8"] =	{
		{
			{"EN", "Profesion:"},
			{"HR", "Zanimanje:"}
		}
	};
    translation["BBack"] =	{
		{
			{"EN", "Back to login"},
			{"HR", "Nazad na prijavu"}
		}
	};
	translation["Bucitaj"] =	{
		{
			{"EN", "Load image"},
			{"HR", "U�itaj sliku"}
		}
	};
		translation["BucitajKlubovi"] =	{
		{
			{"EN", "Load image"},
			{"HR", "U�itaj sliku"}
		}
	};
		translation["BSortiraj"] =	{
		{
			{"EN", "Sort"},
			{"HR", "Sortiraj"}
		}
	};
		translation["BAzuriraj"] =	{
		{
			{"EN", "Update selected"},
			{"HR", "Azuriraj odabrano"}
		}
	};
		translation["BSpremi"] =	{
		{
			{"EN", "Save"},
			{"HR", "Spremi"}
		}
	};
		translation["BPromijeni"] =	{
		{
			{"EN", "Clubs"},
			{"HR", "Klubovi"}
		}
	};
		translation["BPromjeniOsobe"] =	{
		{
			{"EN", "Official personel"},
			{"HR", "Slu�bene osobe"}
		}
	};
       	translation["CBBackground"] =	{
		{
			{"EN", "Dark Mode"},
			{"HR", "Tamni Na�in"}
		}
	};
	translation["Label6"] =	{
		{
			{"EN", "Font size:"},
			{"HR", "Veli�ina fonta:"}
		}
	};
		translation["Bsortiraj"] =	{
		{
			{"EN", "Sort"},
			{"HR", "Sortiraj"}
		}
	};
	translation["CBFilteri"] =	{
		{
			{"EN", "Filter"},
			{"HR", "Filtriraj"}
		}
	};
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BucitajClick(TObject *Sender)
{
	if(OpenDialog1->Execute()){
		DMBaza->ADOSluzbeneOsobe->Edit();
		static_cast<TBlobField*>(DMBaza->ADOSluzbeneOsobe->FieldByName("Avatar"))->LoadFromFile(OpenDialog1->FileName);
		DMBaza->ADOSluzbeneOsobe->Post();

	}
	if(DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text == "Sudac"){
		HINSTANCE ResourceDll;
		if((ResourceDll = LoadLibrary(L"DLLProject1"))==NULL){
			ShowMessage("cannot load dll!");
			return;
		}
		TResourceStream* rs = new TResourceStream((int)ResourceDll, "ReffereAvatar", RT_RCDATA);

		DMBaza->ADOSluzbeneOsobe->Edit();
		static_cast<TBlobField*>(DMBaza->ADOSluzbeneOsobe->FieldByName("Avatar"))->LoadFromStream(rs);
		DMBaza->ADOSluzbeneOsobe->Post();
		delete rs;
		FreeLibrary(ResourceDll);
	}
	if(DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text == "Delegat"){

		HINSTANCE ResourceDll;
		if((ResourceDll = LoadLibrary(L"DLLProject1"))==NULL){
			ShowMessage("cannot load dll!");
			return;
		}
		TResourceStream* rs = new TResourceStream((int)ResourceDll, "DelegateAvatar", RT_RCDATA);
		DMBaza->ADOSluzbeneOsobe->Edit();
		static_cast<TBlobField*>(DMBaza->ADOSluzbeneOsobe->FieldByName("Avatar"))->LoadFromStream(rs);
		DMBaza->ADOSluzbeneOsobe->Post();
        delete rs;
		FreeLibrary(ResourceDll);
	}
	if(DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text == "Doktor"){

        HINSTANCE ResourceDll;
		if((ResourceDll = LoadLibrary(L"DLLProject1"))==NULL){
			ShowMessage("cannot load dll!");
			return;
		}
		TResourceStream* rs = new TResourceStream((int)ResourceDll, "DoctorAvatar", RT_RCDATA);
		DMBaza->ADOSluzbeneOsobe->Edit();
		static_cast<TBlobField*>(DMBaza->ADOSluzbeneOsobe->FieldByName("Avatar"))->LoadFromFile("DoctorAvatar.jpg");
		DMBaza->ADOSluzbeneOsobe->Post();
        delete rs;
		FreeLibrary(ResourceDll);
	}

}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BPromijeniClick(TObject *Sender)
{
	DBGrid1->Visible = FALSE;
	EIme->Visible = FALSE;
	EPrezime->Visible = FALSE;
	EAdresa->Visible = FALSE;
	EIBAN->Visible = FALSE;
	CBZanimanja->Visible = FALSE;
	EUsername->Visible = FALSE;
	EPassword->Visible = FALSE;
	DBIOsoba->Visible = FALSE;
	Label3->Visible = FALSE;
	Label4->Visible = FALSE;
	Label5->Visible = FALSE;
	Label7->Visible = FALSE;
	Label8->Visible = FALSE;
	DBNOsobe->Visible = FALSE;
	Label11->Visible = FALSE;
	EOib->Visible = FALSE;
	Bucitaj->Visible = FALSE;
	BSpremi->Visible = FALSE;
	BAzuriraj->Visible = FALSE;
	DBGrid2->Visible = TRUE;
	DBENazivKlub->Visible = TRUE;
	DBEAdresaKlub->Visible = TRUE;
	DBIKlubovi->Visible = TRUE;
	DBNKlub->Visible = TRUE;
	DBEUsernameKlub->Visible = TRUE;
	DBEPasswordKlub->Visible = TRUE;
	Label9->Visible = TRUE;
	Label10->Visible = TRUE;
	BUcitajKlubovi->Visible = TRUE;
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BPromjeniOsobeClick(TObject *Sender)
{
	DBGrid1->Visible = TRUE;
	EIme->Visible = TRUE;
	EPrezime->Visible = TRUE;
	EAdresa->Visible = TRUE;
	EIBAN->Visible = TRUE;
	CBZanimanja->Visible = TRUE;
	EUsername->Visible = TRUE;
	EPassword->Visible = TRUE;
	DBIOsoba->Visible = TRUE;
	DBNOsobe->Visible = TRUE;
	Label3->Visible = TRUE;
	Label4->Visible = TRUE;
	Label5->Visible = TRUE;
	Label7->Visible = TRUE;
	Label8->Visible = TRUE;
	Label11->Visible = TRUE;
	Bucitaj->Visible = TRUE;
	EOib->Visible = TRUE;
	BSpremi->Visible = TRUE;
	BAzuriraj->Visible = TRUE;
	DBGrid2->Visible = FALSE;
	DBENazivKlub->Visible = FALSE;
	DBEAdresaKlub->Visible = FALSE;
	DBIKlubovi->Visible = FALSE;
	DBEUsernameKlub->Visible = FALSE;
	DBNKlub->Visible = FALSE;
	DBEPasswordKlub->Visible = FALSE;
	Label9->Visible = FALSE;
	Label10->Visible = FALSE;
	BUcitajKlubovi->Visible = FALSE;
}
//---------------------------------------------------------------------------


void __fastcall TFNoviKorisnik::CBBackgroundClick(TObject *Sender)
{
	if(CBBackground->Checked){
	  FNoviKorisnik->Color = clGray;

	 }
	 else{
	 	FNoviKorisnik->Color = clBtnFace;
	 }
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::EFontChange(TObject *Sender)
{
    FNoviKorisnik->Font->Size = EFont->Text.ToInt();
}
//---------------------------------------------------------------------------


void __fastcall TFNoviKorisnik::FormClose(TObject *Sender, TCloseAction &Action)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	ini->WriteInteger("Main Window", "Left", Left);
	ini->WriteInteger("Main Window", "Top", Top);
	ini->WriteInteger("Main Window", "Width", Width);
	ini->WriteInteger("Main Window", "Height", Height);
	if (CBBackground->Checked)
		ini->WriteBool("Main Window", "Dark mode", TRUE);
	else
		ini->WriteBool("Main Window", "Dark mode", FALSE);

	ini->WriteString("Main Window", "Font size", EFont->Text);

	if(RBENG->Checked)
		ini->WriteString("Main Window", "Language", "ENG");
	else
        ini->WriteString("Main Window", "Language", "HR");
	delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::FormCreate(TObject *Sender)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	Left = ini->ReadInteger("Main Window", "Left", 0);
	Top = ini->ReadInteger("Main Window", "Top", 0);
	Width = ini->ReadInteger("Main Window", "Width", 800);
	Height = ini->ReadInteger("Main Window", "Height", 500);
	if(ini->ReadBool("Main Window", "Dark mode", FALSE))
		CBBackground->Checked = TRUE;
	else
		CBBackground->Checked = FALSE;

	String temp = ini->ReadString("Main Window", "Font size", 12);
	EFont->Text = temp;
    FNoviKorisnik->Font->Size = EFont->Text.ToInt();

	if(ini->ReadString("Main Window", "Language","ENG") == "ENG")
		RBENG->Checked = TRUE;
	else
        RBHR->Checked = TRUE;
	delete ini;

}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BBackClick(TObject *Sender)
{
	FNoviKorisnik->Close();
    FLogin->Show();
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::RBENGClick(TObject *Sender)
{
	translateForm(this, "EN", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::RBHRClick(TObject *Sender)
{
    translateForm(this, "HR", translation);
}
//---------------------------------------------------------------------------


void __fastcall TFNoviKorisnik::BSortirajClick(TObject *Sender)
{
	DMBaza->ADOSluzbeneOsobe->IndexFieldNames = "Ime;Prezime";
	DMBaza->ADOKlubovi->IndexFieldNames = "Naziv";
}
//---------------------------------------------------------------------------
void __fastcall TFNoviKorisnik::CBFilteriClick(TObject *Sender)
{
    if(CBFilteri->Checked && !EFilter->Text.IsEmpty())
	{
		DMBaza->ADOSluzbeneOsobe->Filter = "Ime LIKE " + QuotedStr(EFilter->Text + "%");
        DMBaza->ADOKlubovi->Filter = "Naziv LIKE " + QuotedStr(EFilter->Text + "%");
	}
    DMBaza->ADOSluzbeneOsobe->Filtered = CBFilteri->Checked;
}
//---------------------------------------------------------------------------


void __fastcall TFNoviKorisnik::BUcitajKluboviClick(TObject *Sender)
{

	if(OpenDialog1->Execute()){
		DMBaza->ADOKlubovi->Edit();
		static_cast<TBlobField*>(DMBaza->ADOKlubovi->FieldByName("Grb"))->LoadFromFile(OpenDialog1->FileName);
		DMBaza->ADOKlubovi->Post();

	}
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::DBGrid1CellClick(TColumn *Column)
{
	TLocateOptions Opts;
	Opts.Clear();
	Opts << loCaseInsensitive;

	DMBaza->ADOSluzbeneOsobe->Locate("ID", DBGrid1->SelectedIndex , Opts);
	EUsername->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Username")->Text;
	EPassword->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->Text;
	EIme->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Ime")->Text;
	EPrezime->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Prezime")->Text;
	EIBAN->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("IBAN")->Text;
	CBZanimanja->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text;

	String decodedMessage2;
	ETemp->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Adresa")->Text;
	Codec1->Password = "0v0j3jak0duga1k0mpl1c1ranal0z1nkasabr0j3v1maumjest0sl0va";
	Codec1->DecryptString(decodedMessage2,ETemp->Text, TEncoding::ANSI);
	EAdresa->Text = decodedMessage2;
	EOib->Text =  DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text;

	String decodedMessage;
	ETemp->Text =  DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text;

	std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
	privateKey->LoadFromFile("private_key.bin");
	Signatory1->LoadKeysFromStream(privateKey.get(), TKeyStoragePartSet() << partPrivate);
	CodecRSA->DecryptString(decodedMessage, ETemp->Text, TEncoding::ANSI);
	EOib->Text = decodedMessage;

    CBZanimanja->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text;

}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BSpremiClick(TObject *Sender)
{
	DMBaza->ADOSluzbeneOsobe->Append();

	DMBaza->ADOSluzbeneOsobe->FieldByName("Username")->Text = EUsername->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->Text = Stream_To_Hex(Hash1->HashOutputValue);
	DMBaza->ADOSluzbeneOsobe->FieldByName("Ime")->Text = EIme->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("Prezime")->Text = EPrezime->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("IBAN")->Text = EIBAN->Text;

	String Oib = DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text;
	String encodedMessage;
	std::unique_ptr<TMemoryStream> publicKey (new TMemoryStream);
	publicKey->LoadFromFile("E:/SCHOOL/4.semestar/Napredne tehnike programiranja/Projekt/public_key.bin");
	Signatory1->LoadKeysFromStream(publicKey.get(), TKeyStoragePartSet() << partPublic);
	CodecRSA->EncryptString(Oib, encodedMessage, TEncoding::ANSI);

	DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text = encodedMessage;

	String encodedMessage2;
	Codec1->Password = "0v0j3jak0duga1k0mpl1c1ranal0z1nkasabr0j3v1maumjest0sl0va";
	Codec1->EncryptString(EAdresa->Text,encodedMessage2, TEncoding::ANSI);
	DMBaza->ADOSluzbeneOsobe->FieldByName("Adresa")->Text = encodedMessage2;

	DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text = CBZanimanja->Text;

	HashMD->HashString(EOib->Text, TEncoding::ANSI);
	String temp = Stream_To_Hex(HashMD->HashOutputValue);
	Hash1->HashString(temp + EPassword->Text, TEncoding::ANSI);
	DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->Text = Stream_To_Hex(Hash1->HashOutputValue);

	DMBaza->ADOSluzbeneOsobe->Post();
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BAzurirajClick(TObject *Sender)
{
	TLocateOptions Opts;
	Opts.Clear();
	Opts << loCaseInsensitive;
	DMBaza->ADOSluzbeneOsobe->Locate("ID", DBGrid1->SelectedIndex , Opts);
	DMBaza->ADOSluzbeneOsobe->Edit();

	DMBaza->ADOSluzbeneOsobe->FieldByName("Username")->Text = EUsername->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("Ime")->Text = EIme->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("Prezime")->Text = EPrezime->Text;
	DMBaza->ADOSluzbeneOsobe->FieldByName("IBAN")->Text = EIBAN->Text;

	String Oib = EOib->Text;
	String encodedMessage;
	std::unique_ptr<TMemoryStream> publicKey (new TMemoryStream);
	publicKey->LoadFromFile("E:/SCHOOL/4.semestar/Napredne tehnike programiranja/Projekt/public_key.bin");
	Signatory1->LoadKeysFromStream(publicKey.get(), TKeyStoragePartSet() << partPublic);
	CodecRSA->EncryptString(Oib, encodedMessage, TEncoding::ANSI);

	DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text = encodedMessage;

	String encodedMessage2;
	Codec1->Password = "0v0j3jak0duga1k0mpl1c1ranal0z1nkasabr0j3v1maumjest0sl0va";
	Codec1->EncryptString(EAdresa->Text,encodedMessage2, TEncoding::ANSI);

	DMBaza->ADOSluzbeneOsobe->FieldByName("Adresa")->Text = encodedMessage2;

	HashMD->HashString(EOib->Text, TEncoding::ANSI);
	String temp = Stream_To_Hex(HashMD->HashOutputValue);
	Hash1->HashString(temp + EPassword->Text, TEncoding::ANSI);
	DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->Text = Stream_To_Hex(Hash1->HashOutputValue);

	DMBaza->ADOSluzbeneOsobe->Post();
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::KljuceviClick(TObject *Sender)
{
    std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
	std::unique_ptr<TMemoryStream> publicKey (new TMemoryStream);
	if(Signatory1->GenerateKeys()){
		Signatory1->StoreKeysToStream(privateKey.get(), TKeyStoragePartSet() << partPrivate);
		Signatory1->StoreKeysToStream(publicKey.get(), TKeyStoragePartSet() << partPublic);
		privateKey->SaveToFile("private_key.bin");
		publicKey->SaveToFile("public_key.bin");
	}
}
//---------------------------------------------------------------------------

void __fastcall TFNoviKorisnik::BTempClick(TObject *Sender)
{
	//String temp = HashMD->HashString(EOib->Text, TEncoding::ANSI);
	//Hash1->HashString(temp + EPassword->Text, TEncoding::ANSI);
}
//---------------------------------------------------------------------------

