//---------------------------------------------------------------------------

#ifndef Stadioni1H
#define Stadioni1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Xml.Win.msxmldom.hpp>
#include <Xml.XMLDoc.hpp>
#include <Xml.xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <Vcl.Mask.hpp>
#include <map>
//---------------------------------------------------------------------------
class TFStadioniPopis : public TForm
{
__published:	// IDE-managed Components
	TListView *ListView1;
	TButton *Button1;
	TButton *Button2;
	TButton *Button3;
	TGroupBox *GBNoviStadion;
	TGroupBox *GBCustom;
	TLabel *Label6;
	TCheckBox *CBBackground;
	TEdit *EFont;
	TUpDown *UpDown1;
	TGroupBox *GBLang;
	TRadioButton *RBENG;
	TRadioButton *RBHR;
	TXMLDocument *XMLStadioni;
	TLabeledEdit *LENaziv;
	TLabeledEdit *LEAdresa;
	TLabeledEdit *LEKapacitet;
	TLabeledEdit *LECijena;
	TButton *BOdaberi;
	TButton *BAzuriraj;
	TEdit *ENazivTemp;
	TEdit *EAdresaTemp;
	TLabel *Label1;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall CBBackgroundClick(TObject *Sender);
	void __fastcall EFontChange(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall BOdaberiClick(TObject *Sender);
	void __fastcall ListView1Click(TObject *Sender);
	void __fastcall BAzurirajClick(TObject *Sender);
	void __fastcall RBENGClick(TObject *Sender);
	void __fastcall RBHRClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	std::map<String, std::map<String, String>> translation;
	__fastcall TFStadioniPopis(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFStadioniPopis *FStadioniPopis;
//---------------------------------------------------------------------------
#endif
