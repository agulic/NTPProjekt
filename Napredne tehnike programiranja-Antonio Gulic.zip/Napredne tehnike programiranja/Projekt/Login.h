//---------------------------------------------------------------------------

#ifndef LoginH
#define LoginH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include "uTPLb_Hash.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_Signatory.hpp"
#include <System.SysUtils.hpp>
#include <map>
//---------------------------------------------------------------------------
class TFLogin : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GBLogin;
	TEdit *EUsername;
	TLabel *Label1;
	TLabel *Label2;
	TEdit *EPassword;
	TButton *BLogin;
	TGroupBox *GBLang;
	TGroupBox *GBCustom;
	TCheckBox *CBBackground;
	TLabel *Label3;
	TEdit *EFont;
	TUpDown *UpDown1;
	TRadioButton *RBENG;
	TRadioButton *RBHR;
	TButton *BNoviKorisnik;
	TLabel *LError;
	THash *Hash1;
	TCryptographicLibrary *CLLogin;
	TSignatory *Signatory1;
	TCodec *CodecRSA;
	TButton *BAdmin;
	void __fastcall CBBackgroundClick(TObject *Sender);
	void __fastcall EFontChange(TObject *Sender);
	void __fastcall BLoginClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall RBENGClick(TObject *Sender);
	void __fastcall RBHRClick(TObject *Sender);
	void __fastcall BNoviKorisnikClick(TObject *Sender);
	void __fastcall BAdminClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	std::map<String, std::map<String, String>> translation;
	__fastcall TFLogin(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFLogin *FLogin;
//---------------------------------------------------------------------------
#endif
