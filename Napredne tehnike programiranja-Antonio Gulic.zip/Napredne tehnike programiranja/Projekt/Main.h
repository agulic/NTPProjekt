//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include "frxClass.hpp"
#include "frxDBSet.hpp"
#include "frxExportBaseDialog.hpp"
#include "frxExportImage.hpp"
#include "frxExportPDF.hpp"
#include "frxExportRTF.hpp"
#include <Vcl.ExtCtrls.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include <System.SysUtils.hpp>
#include <map>
//---------------------------------------------------------------------------
class TFMain : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GroupBox1;
	TLabel *Label1;
	TLabel *Label2;
	TEdit *Eime;
	TEdit *Eprezime;
	TLabel *Label3;
	TEdit *Eadresa;
	TGroupBox *GBStadion;
	TLabel *Label4;
	TEdit *EStadionNaziv;
	TLabel *Label5;
	TGroupBox *GBCustom;
	TLabel *Label6;
	TCheckBox *CBBackground;
	TEdit *EFont;
	TUpDown *UpDown1;
	TLabel *Label7;
	TEdit *EPutovanje;
	TLabel *Label8;
	TRadioButton *RadioButton1;
	TRadioButton *RadioButton2;
	TRadioButton *RadioButton3;
	TRadioButton *RadioButton4;
	TGroupBox *GBUtakmica;
	TComboBox *CBLiga;
	TLabel *Label9;
	TLabel *Label10;
	TEdit *Ekolo;
	TUpDown *UpDown2;
	TLabel *Label11;
	TLabel *Label12;
	TButton *BUcitajStadion;
	TLabel *Label13;
	TEdit *EIBAN;
	TRadioButton *RBGlavniSudac;
	TRadioButton *RBPomocniSudac;
	TRadioButton *RBCetvrtiSudac;
	TGroupBox *GBLang;
	TRadioButton *RBENG;
	TRadioButton *RBHR;
	TEdit *EAdresaStadion;
	TButton *BBack;
	TButton *BOsvjezi;
	TButton *BGeneriraj;
	TDBLookupComboBox *DBLDomaci;
	TDBLookupComboBox *DBLGosti;
	TDBGrid *DBGrid1;
	TDateTimePicker *DTPMain;
	TLabel *Label14;
	TfrxDBDataset *frxDBDataset1;
	TfrxReport *FRMain;
	TfrxPNGExport *frxPNGExport1;
	TfrxPDFExport *frxPDFExport1;
	TfrxRTFExport *frxRTFExport1;
	TfrxJPEGExport *frxJPEGExport1;
	TfrxBMPExport *frxBMPExport1;
	TDBNavigator *DBNavigator1;
	TIdTCPClient *TCPClient;
	TButton *BCijena;
	TButton *BNalog;
	TCryptographicLibrary *CryptographicLibrary1;
	TCodec *Codec1;
	TCodec *Codec2;
	TCryptographicLibrary *CLMain;
	void __fastcall CBBackgroundClick(TObject *Sender);
	void __fastcall EFontChange(TObject *Sender);
	void __fastcall EPutovanjeClick(TObject *Sender);
	void __fastcall BUcitajStadionClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall RBHRClick(TObject *Sender);
	void __fastcall RBENGClick(TObject *Sender);
	void __fastcall BBackClick(TObject *Sender);
	void __fastcall BOsvjeziClick(TObject *Sender);
	void __fastcall BGenerirajClick(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall BCijenaClick(TObject *Sender);
	void __fastcall BNalogClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	std::map<String, std::map<String, String>> translation;
	__fastcall TFMain(TComponent* Owner);
};

//---------------------------------------------------------------------------
extern PACKAGE TFMain *FMain;
//---------------------------------------------------------------------------
#endif
