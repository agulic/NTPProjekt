//---------------------------------------------------------------------------

#ifndef DBFormH
#define DBFormH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
//---------------------------------------------------------------------------
class TDMBaza : public TDataModule
{
__published:	// IDE-managed Components
	TADOConnection *ADOBazaPodataka;
	TADOTable *ADOKlubovi;
	TADOTable *ADOSluzbeneOsobe;
	TADOTable *ADOGotoviZapisnici;
	TDataSource *DSKlubovi;
	TDataSource *DSSluzbeneOsobe;
	TDataSource *DSGotoviZapisnici;
	TADOTable *ADOZanimanje;
	TDataSource *DSZanimanje;
	TAutoIncField *ADOZanimanjeID;
	TWideStringField *ADOZanimanjeZanimanje;
	TAutoIncField *ADOSluzbeneOsobeID;
	TWideStringField *ADOSluzbeneOsobeUsername;
	TWideStringField *ADOSluzbeneOsobeIme;
	TWideStringField *ADOSluzbeneOsobePrezime;
	TWideStringField *ADOSluzbeneOsobeAdresa;
	TWideStringField *ADOSluzbeneOsobeZanimanje;
	TWideStringField *ADOSluzbeneOsobeIBAN;
	TBooleanField *ADOSluzbeneOsobeAdmin;
	TBlobField *ADOSluzbeneOsobeAvatar;
	TAutoIncField *ADOKluboviID;
	TWideStringField *ADOKluboviUsername;
	TWideStringField *ADOKluboviNaziv;
	TWideStringField *ADOKluboviAdresa;
	TBlobField *ADOKluboviGrb;
	TADOTable *ADOLige;
	TADOTable *ADOCijena;
	TDataSource *DSLige;
	TDataSource *DSCijena;
	TAutoIncField *ADOGotoviZapisniciID;
	TWideStringField *ADOGotoviZapisniciImeKluba;
	TWideStringField *ADOGotoviZapisniciImeSluzbeneOsobe;
	TWideStringField *ADOGotoviZapisniciPrezimeSluzbeneOsobe;
	TWideStringField *ADOGotoviZapisniciAdresaSluzbeneOsobe;
	TWideStringField *ADOGotoviZapisniciIBANSluzbeneOsobe;
	TWideStringField *ADOGotoviZapisniciLiga;
	TIntegerField *ADOGotoviZapisniciKolo;
	TWideStringField *ADOGotoviZapisniciGost;
	TWideStringField *ADOGotoviZapisniciObavljenaDu�nost;
	TWideStringField *ADOGotoviZapisniciStadion;
	TWideStringField *ADOGotoviZapisniciAdresaStadiona;
	TDateTimeField *ADOGotoviZapisniciDatum;
	TIntegerField *ADOGotoviZapisniciUdaljenost;
	TWideStringField *ADOGotoviZapisniciCijenaKM;
	TIntegerField *ADOGotoviZapisniciUkupnaCijena;
	TWideStringField *ADOSluzbeneOsobePassword;
	TWideStringField *ADOKluboviPassword;
	TWideStringField *ADOSluzbeneOsobeOIB;
private:	// User declarations
public:		// User declarations
	__fastcall TDMBaza(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDMBaza *DMBaza;
//---------------------------------------------------------------------------
#endif
