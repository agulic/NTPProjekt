//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------
USEFORM("NoviKorisnik.cpp", FNoviKorisnik);
USEFORM("Stadioni1.cpp", FStadioniPopis);
USEFORM("MainKlubovi.cpp", FMainKlubovi);
USEFORM("DBForm.cpp", DMBaza); /* TDataModule: File Type */
USEFORM("Login.cpp", FLogin);
USEFORM("Main.cpp", FMain);
//---------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TFLogin), &FLogin);
		Application->CreateForm(__classid(TFMain), &FMain);
		Application->CreateForm(__classid(TFStadioniPopis), &FStadioniPopis);
		Application->CreateForm(__classid(TDMBaza), &DMBaza);
		Application->CreateForm(__classid(TFNoviKorisnik), &FNoviKorisnik);
		Application->CreateForm(__classid(TFMainKlubovi), &FMainKlubovi);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
