//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Login.h"
#include "Main.h"
#include <Registry.hpp>
#include "DBForm.h"
#include "NoviKorisnik.h"
#include "MainKlubovi.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Hash"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
TFLogin *FLogin;

//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i = 0; i < Form->ComponentCount; i++) // iterate though all components on the form
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first) // find component by name
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language) // find translation for the target language
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}

//---------------------------------------------------------------------------
__fastcall TFLogin::TFLogin(TComponent* Owner)
	: TForm(Owner)
{
	translation["Label1"] =	{
		{
			{"EN", "Username:"},
			{"HR", "Korisni�ko ime:"}
		}
	};
	translation["Label2"] =	{
		{
			{"EN", "Password:"},
			{"HR", "Lozinka:"}
		}
	};
	translation["BLogin"] =	{
		{
			{"EN", "Login"},
			{"HR", "Prijava"}
		}
	};
	translation["CBBackground"] =	{
		{
			{"EN", "Dark Mode"},
			{"HR", "Tamni Na�in"}
		}
	};
	translation["Label3"] =	{
		{
			{"EN", "Font size:"},
			{"HR", "Veli�ina fonta:"}
		}
	};
	translation["BNoviKorisnik"] =	{
		{
			{"EN", "Add new user"},
			{"HR", "Dodaj novog korisnika"}
		}
	};
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::CBBackgroundClick(TObject *Sender)
{
 if(CBBackground->Checked){
  FLogin->Color = clGray;

 }
 else{
	  FLogin->Color = clBtnFace;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::EFontChange(TObject *Sender)
{
	FLogin->Font->Size = EFont->Text.ToInt();
}
//---------------------------------------------------------------------------


void __fastcall TFLogin::BLoginClick(TObject *Sender)
{
	TLocateOptions Opts;
	Opts.Clear();
	Opts << loCaseInsensitive;  // zanemari velika i mala slova

	String Oib;
	String temp =  DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text;

	std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
	privateKey->LoadFromFile("private_key.bin");
	FNoviKorisnik->Signatory1->LoadKeysFromStream(privateKey.get(), TKeyStoragePartSet() << partPrivate);
	FNoviKorisnik->CodecRSA->DecryptString(Oib, temp, TEncoding::ANSI);


	if(DMBaza->ADOSluzbeneOsobe->Locate("Username", EUsername->Text, Opts) == true)
	{   String Lozinka =  DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->AsString;
		FNoviKorisnik->HashMD->HashString(Oib, TEncoding::ANSI);
		temp = Stream_To_Hex(FNoviKorisnik->HashMD->HashOutputValue);
		FNoviKorisnik->Hash1->HashString(temp + EPassword->Text, TEncoding::ANSI);
		String LozinkaUnesena = Stream_To_Hex(FNoviKorisnik->Hash1->HashOutputValue);
		if(LozinkaUnesena  == Lozinka)
		{
			FMain->Show();
			FLogin->Hide();
		}
		else  {
			LError->Visible = TRUE;
			LError->Caption = "Kriva lozinka / Wrong Password";
		}

	}
	 else if(DMBaza->ADOKlubovi->Locate("Username", EUsername->Text, Opts) == true){
			String Lozinka =  DMBaza->ADOKlubovi->FieldByName("Password")->AsString;
		if(EPassword->Text  == Lozinka)
		{
			FMainKlubovi->Show();
			FLogin->Hide();
		}
	 }

	 else
	 {
		   LError->Visible = TRUE;
		   LError->Caption = "Korisnik ne postoji / User does not exist";
	 }

	 EUsername->Clear();
	 EPassword->Clear();





}
//---------------------------------------------------------------------------

void __fastcall TFLogin::FormClose(TObject *Sender, TCloseAction &Action)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	ini->WriteInteger("Main Window", "Left", Left);
	ini->WriteInteger("Main Window", "Top", Top);
	ini->WriteInteger("Main Window", "Width", Width);
	ini->WriteInteger("Main Window", "Height", Height);
	if (CBBackground->Checked)
		ini->WriteBool("Main Window", "Dark mode", TRUE);
	else
		ini->WriteBool("Main Window", "Dark mode", FALSE);

	ini->WriteString("Main Window", "Font size", EFont->Text);

	if(RBENG->Checked)
		ini->WriteString("Main Window", "Language", "ENG");
	else
        ini->WriteString("Main Window", "Language", "HR");
    delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::FormCreate(TObject *Sender)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	Left = ini->ReadInteger("Main Window", "Left", 0);
	Top = ini->ReadInteger("Main Window", "Top", 0);
	Width = ini->ReadInteger("Main Window", "Width", 800);
	Height = ini->ReadInteger("Main Window", "Height", 500);
	if(ini->ReadBool("Main Window", "Dark mode", FALSE))
		CBBackground->Checked = TRUE;
	else
		CBBackground->Checked = FALSE;

	String temp = ini->ReadString("Main Window", "Font size", 12);
	EFont->Text = temp;
    FLogin->Font->Size = EFont->Text.ToInt();

	if(ini->ReadString("Main Window", "Language","ENG") == "ENG")
		RBENG->Checked = TRUE;
	else
        RBHR->Checked = TRUE;
	delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::RBENGClick(TObject *Sender)
{
	translateForm(this, "EN", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::RBHRClick(TObject *Sender)
{
    translateForm(this, "HR", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::BNoviKorisnikClick(TObject *Sender)
{
	TLocateOptions Opts;
	Opts.Clear();
	Opts << loCaseInsensitive;  // zanemari velika i mala slova

	String Oib1;
	String temp =  DMBaza->ADOSluzbeneOsobe->FieldByName("OIB")->Text;

	std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
	privateKey->LoadFromFile("private_key.bin");
	FNoviKorisnik->Signatory1->LoadKeysFromStream(privateKey.get(), TKeyStoragePartSet() << partPrivate);
	FNoviKorisnik->CodecRSA->DecryptString(Oib1, temp, TEncoding::ANSI);
	String Oib = Oib1;


	if(DMBaza->ADOSluzbeneOsobe->Locate("Username", EUsername->Text, Opts) == true)
	{   String Lozinka =  DMBaza->ADOSluzbeneOsobe->FieldByName("Password")->AsString;
		bool Admin = DMBaza->ADOSluzbeneOsobe->FieldByName("Admin")->AsBoolean;
		FNoviKorisnik->HashMD->HashString(Oib, TEncoding::ANSI);
		temp = Stream_To_Hex(FNoviKorisnik->HashMD->HashOutputValue);
		FNoviKorisnik->Hash1->HashString(temp + EPassword->Text, TEncoding::ANSI);
		String LozinkaUnesena = Stream_To_Hex(FNoviKorisnik->Hash1->HashOutputValue);
		if(LozinkaUnesena  == Lozinka && Admin)
		{
			FNoviKorisnik->Show();
			FLogin->Hide();
		}
		else if(EPassword->Text  != Lozinka){
			LError->Visible = TRUE;
			LError->Caption = "Kriva lozinka / Wrong Password";

		}
		else  {
			LError->Visible = TRUE;
			LError->Caption = "Korisnik nije administrator / User is not admin";
		}

	}
	 else
	 {
		   LError->Visible = TRUE;
		   LError->Caption = "Korisnik ne postoji / User does not exist";
	 }
     EUsername->Clear();
	 EPassword->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TFLogin::BAdminClick(TObject *Sender)
{
	FNoviKorisnik->Show();
    FLogin->Hide();
}
//---------------------------------------------------------------------------

