//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Stadioni1.h"
#include <Registry.hpp>
#include "Stadioni.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFStadioniPopis *FStadioniPopis;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i = 0; i < Form->ComponentCount; i++) // iterate though all components on the form
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first) // find component by name
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language) // find translation for the target language
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}

//---------------------------------------------------------------------------
__fastcall TFStadioniPopis::TFStadioniPopis(TComponent* Owner)
	: TForm(Owner)
{
	translation["Button1"] =	{
		{
			{"EN", "Load stadium"},
			{"HR", "U�itaj stadion"}
		}
	};
	translation["Button2"] =	{
		{
			{"EN", "Add"},
			{"HR", "Dodaj"}
		}
	};
	translation["Button3"] =	{
		{
			{"EN", "Delete stadium"},
			{"HR", "Obri�i stadion"}
		}
	};
	translation["BAzuriraj"] =	{
		{
			{"EN", "Update existing"},
			{"HR", "A�uriraj postoje�i"}
		}
	};
	translation["BOdaberi"] =	{
		{
			{"EN", "Select stadium"},
			{"HR", "Odaberi stadion"}
		}
	};
	translation["CBBackground"] =	{
		{
			{"EN", "Dark Mode"},
			{"HR", "Tamni Na�in"}
		}
	};
	translation["Label6"] =	{
		{
			{"EN", "Font size:"},
			{"HR", "Veli�ina fonta:"}
		}
	};
	translation["LENaziv.SubLabel"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Naziv:"}
		}
	};
	translation["LEAdresa.SubLable"] =	{
		{
			{"EN", "Adress:"},
			{"HR", "Adresa:"}
		}
	};
	translation["LEKapacitet.SubLable"] =	{
		{
			{"EN", "Capacity:"},
			{"HR", "Kapacitet:"}
		}
	};
	translation["LECijena.SubLable"] =	{
		{
			{"EN", "Ticket price:"},
			{"HR", "Cijena Ulaznice:"}
		}
	};
	translation["GBNoviStadion"] =	{
		{
			{"EN", "New stadium:"},
			{"HR", "Novi stadion:"}
		}
	};
		translation["ListView1.Columns[0]"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Naziv:"}
		}
	};
	translation["ListView1.Columns[1]"] =	{
		{
			{"EN", "Adress:"},
			{"HR", "Adresa:"}
		}
	};
	translation["ListView1.Columns[2]"] =	{
		{
			{"EN", "Capacity:"},
			{"HR", "Kapacitet:"}
		}
	};
	translation["ListView1.Columns[3]"] =	{
		{
			{"EN", "Ticket price:"},
			{"HR", "Cijena Ulaznice:"}
		}
	};
}
//---------------------------------------------------------------------------
void __fastcall TFStadioniPopis::FormClose(TObject *Sender, TCloseAction &Action)

{
             TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	ini->WriteInteger("Main Window", "Left", Left);
	ini->WriteInteger("Main Window", "Top", Top);
	ini->WriteInteger("Main Window", "Width", Width);
	ini->WriteInteger("Main Window", "Height", Height);
	if (CBBackground->Checked)
		ini->WriteBool("Main Window", "Dark mode", TRUE);
	else
		ini->WriteBool("Main Window", "Dark mode", FALSE);

	ini->WriteString("Main Window", "Font size", EFont->Text);

	if(RBENG->Checked)
		ini->WriteString("Main Window", "Language", "ENG");
	else
        ini->WriteString("Main Window", "Language", "HR");
    delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::FormCreate(TObject *Sender)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	Left = ini->ReadInteger("Main Window", "Left", 0);
	Top = ini->ReadInteger("Main Window", "Top", 0);
	Width = ini->ReadInteger("Main Window", "Width", 800);
	Height = ini->ReadInteger("Main Window", "Height", 500);
	if(ini->ReadBool("Main Window", "Dark mode", FALSE))
		CBBackground->Checked = TRUE;
	else
		CBBackground->Checked = FALSE;

	String temp = ini->ReadString("Main Window", "Font size", 12);
	EFont->Text = temp;
    FStadioniPopis->Font->Size = EFont->Text.ToInt();

	if(ini->ReadString("Main Window", "Language","ENG") == "ENG")
		RBENG->Checked = TRUE;
	else
        RBHR->Checked = TRUE;
	delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::CBBackgroundClick(TObject *Sender)
{
    if(CBBackground->Checked){
  FStadioniPopis->Color = clGray;

 }
 else{
	  FStadioniPopis->Color = clBtnFace;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::EFontChange(TObject *Sender)
{
    FStadioniPopis->Font->Size = EFont->Text.ToInt();
}
//---------------------------------------------------------------------------


void __fastcall TFStadioniPopis::Button1Click(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);


    ListView1->Items->Clear();
	for(int i = 0; i < Stadioni->Count;i++)
		{
			ListView1->Items->Add();
			ListView1->Items->Item[i]->Caption = Stadioni->Stadion[i]->Naziv;
			ListView1->Items->Item[i]->SubItems->Add(Stadioni->Stadion[i]->Adresa);
			ListView1->Items->Item[i]->SubItems->Add(Stadioni->Stadion[i]->Kapacitet);
			ListView1->Items->Item[i]->SubItems->Add(Stadioni->Stadion[i]->Cijena);
		}
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::Button2Click(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);
	_di_IXMLStadionType Stadion = Stadioni->Add();

	Stadion->Naziv = LENaziv->Text;
	Stadion->Adresa = LEAdresa->Text;
	Stadion->Kapacitet = LEKapacitet->Text.ToInt();
	Stadion->Cijena = LECijena->Text.ToInt();
	XMLStadioni->SaveToFile(XMLStadioni->FileName);

}
//---------------------------------------------------------------------------


void __fastcall TFStadioniPopis::Button3Click(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);
	Stadioni->Delete(ListView1->ItemIndex);
    XMLStadioni->SaveToFile(XMLStadioni->FileName);
}
//---------------------------------------------------------------------------



void __fastcall TFStadioniPopis::BOdaberiClick(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);
	_di_IXMLStadionType Stadion = Stadioni->Stadion[ListView1->ItemIndex];
	ENazivTemp->Text = Stadion->Naziv;
	EAdresaTemp->Text = Stadion->Adresa;
	FStadioniPopis->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::ListView1Click(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);
	_di_IXMLStadionType Stadion = Stadioni->Stadion[ListView1->ItemIndex];

	LENaziv->Text = Stadion->Naziv;
	LEAdresa->Text = Stadion->Adresa;
	LEKapacitet->Text = Stadion->Kapacitet;
    LECijena->Text = Stadion->Cijena;
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::BAzurirajClick(TObject *Sender)
{
	_di_IXMLStadioniType Stadioni = GetStadioni(XMLStadioni);
	_di_IXMLStadionType Stadion = Stadioni->Stadion[ListView1->ItemIndex];

	Stadion->Naziv = LENaziv->Text;
	Stadion->Adresa = LEAdresa->Text;
	Stadion->Kapacitet = LEKapacitet->Text.ToInt();
	Stadion->Cijena = LECijena->Text.ToInt();
	XMLStadioni->SaveToFile(XMLStadioni->FileName);
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::RBENGClick(TObject *Sender)
{
    translateForm(this, "EN", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFStadioniPopis::RBHRClick(TObject *Sender)
{
    translateForm(this, "HR", translation);
}
//---------------------------------------------------------------------------

