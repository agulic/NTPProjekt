
// **************************************** //
//                                        
//            XML Data Binding            
//                                        
//         Generated on: 8.4.2022. 16:13:34 
//       Generated from: Stadioni.xml     
//   Settings stored in: Stadioni.xdb     
//                                        
// **************************************** //

#include <System.hpp>
#pragma hdrstop

#include "Stadioni.h"


// Global Functions 

_di_IXMLStadioniType __fastcall GetStadioni(Xml::Xmlintf::_di_IXMLDocument Doc)
{
  return (_di_IXMLStadioniType) Doc->GetDocBinding("Stadioni", __classid(TXMLStadioniType), TargetNamespace);
};

_di_IXMLStadioniType __fastcall GetStadioni(Xml::Xmldoc::TXMLDocument *Doc)
{
  Xml::Xmlintf::_di_IXMLDocument DocIntf;
  Doc->GetInterface(DocIntf);
  return GetStadioni(DocIntf);
};

_di_IXMLStadioniType __fastcall LoadStadioni(const System::UnicodeString& FileName)
{
  return (_di_IXMLStadioniType) Xml::Xmldoc::LoadXMLDocument(FileName)->GetDocBinding("Stadioni", __classid(TXMLStadioniType), TargetNamespace);
};

_di_IXMLStadioniType __fastcall  NewStadioni()
{
  return (_di_IXMLStadioniType) Xml::Xmldoc::NewXMLDocument()->GetDocBinding("Stadioni", __classid(TXMLStadioniType), TargetNamespace);
};

// TXMLStadioniType 

void __fastcall TXMLStadioniType::AfterConstruction(void)
{
  RegisterChildNode(System::UnicodeString("Stadion"), __classid(TXMLStadionType));
  ItemTag = "Stadion";
  ItemInterface = __uuidof(IXMLStadionType);
  Xml::Xmldoc::TXMLNodeCollection::AfterConstruction();
};

_di_IXMLStadionType __fastcall TXMLStadioniType::Get_Stadion(int Index)
{
  return (_di_IXMLStadionType) List->Nodes[Index];
};

_di_IXMLStadionType __fastcall TXMLStadioniType::Add()
{
  return (_di_IXMLStadionType) AddItem(-1);
};

_di_IXMLStadionType __fastcall TXMLStadioniType::Insert(const int Index)
{
  return (_di_IXMLStadionType) AddItem(Index);
};

// TXMLStadionType 

int __fastcall TXMLStadionType::Get_ID()
{
  return GetAttributeNodes()->Nodes[System::UnicodeString("ID")]->NodeValue.operator int();
};

void __fastcall TXMLStadionType::Set_ID(int Value)
{
  SetAttribute(System::UnicodeString("ID"), Value);
};

System::UnicodeString __fastcall TXMLStadionType::Get_Naziv()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Naziv")]->Text;
};

void __fastcall TXMLStadionType::Set_Naziv(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Naziv")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLStadionType::Get_Adresa()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Adresa")]->Text;
};

void __fastcall TXMLStadionType::Set_Adresa(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Adresa")]->NodeValue = Value;
};

int __fastcall TXMLStadionType::Get_Kapacitet()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Kapacitet")]->NodeValue.operator int();
};

void __fastcall TXMLStadionType::Set_Kapacitet(int Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Kapacitet")]->NodeValue = Value;
};

int __fastcall TXMLStadionType::Get_Cijena()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Cijena")]->NodeValue.operator int();
};

void __fastcall TXMLStadionType::Set_Cijena(int Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Cijena")]->NodeValue = Value;
};
