//---------------------------------------------------------------------------

#ifndef MainKluboviH
#define MainKluboviH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
#include "frxClass.hpp"
#include "frxDBSet.hpp"
#include "frxExportBaseDialog.hpp"
#include "frxExportImage.hpp"
#include "frxExportPDF.hpp"
#include "frxExportRTF.hpp"
#include <Vcl.WinXPickers.hpp>
#include <map>

//---------------------------------------------------------------------------
class TFMainKlubovi : public TForm
{
__published:	// IDE-managed Components
	TDBGrid *DBGrid1;
	TDBNavigator *DBNavigator1;
	TButton *BUcitaj;
	TButton *BBack;
	TButton *BGeneriraj;
	TGroupBox *GBCustom;
	TLabel *Label3;
	TCheckBox *CBBackground;
	TEdit *EFont;
	TUpDown *UpDown1;
	TGroupBox *GBLang;
	TRadioButton *RBENG;
	TRadioButton *RBHR;
	TfrxReport *FRMainKlubovi;
	TfrxDBDataset *frxDBDataset1;
	TfrxBMPExport *frxBMPExport1;
	TfrxJPEGExport *frxJPEGExport1;
	TfrxPNGExport *frxPNGExport1;
	TfrxPDFExport *frxPDFExport1;
	TfrxRTFExport *frxRTFExport1;
	TCheckBox *CBFilter;
	TDateTimePicker *DTFilter;
	void __fastcall BUcitajClick(TObject *Sender);
	void __fastcall BBackClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall CBBackgroundClick(TObject *Sender);
	void __fastcall EFontChange(TObject *Sender);
	void __fastcall RBENGClick(TObject *Sender);
	void __fastcall RBHRClick(TObject *Sender);
	void __fastcall BGenerirajClick(TObject *Sender);
	void __fastcall CBFilterClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    std::map<String, std::map<String, String>> translation;
	__fastcall TFMainKlubovi(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFMainKlubovi *FMainKlubovi;
//---------------------------------------------------------------------------
#endif
