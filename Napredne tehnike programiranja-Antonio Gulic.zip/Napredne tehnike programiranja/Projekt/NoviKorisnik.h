//---------------------------------------------------------------------------

#ifndef NoviKorisnikH
#define NoviKorisnikH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include "uTPLb_Hash.hpp"
#include <System.SysUtils.hpp>
#include "uTPLb_Signatory.hpp"
#include <System.Net.HttpClient.hpp>
#include <System.Net.HttpClientComponent.hpp>
#include <System.Net.URLClient.hpp>
#include <IdBaseComponent.hpp>
#include <IdIntercept.hpp>
#include <IdInterceptThrottler.hpp>
#include <IdComponent.hpp>
#include <IdHTTP.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include <IdIOHandler.hpp>
#include <IdIOHandlerSocket.hpp>
#include <IdIOHandlerStack.hpp>
#include <IdSSL.hpp>
#include <IdSSLOpenSSL.hpp>
#include <map>
//---------------------------------------------------------------------------
class TFNoviKorisnik : public TForm
{
__published:	// IDE-managed Components
	TDBGrid *DBGrid1;
	TDBImage *DBIOsoba;
	TDBNavigator *DBNOsobe;
	TButton *Bucitaj;
	TOpenDialog *OpenDialog1;
	TButton *BPromijeni;
	TDBGrid *DBGrid2;
	TDBEdit *DBENazivKlub;
	TDBEdit *DBEAdresaKlub;
	TDBImage *DBIKlubovi;
	TButton *BPromjeniOsobe;
	TDBEdit *DBEUsernameKlub;
	TDBEdit *DBEPasswordKlub;
	TGroupBox *GBCustom;
	TLabel *Label6;
	TCheckBox *CBBackground;
	TEdit *EFont;
	TUpDown *UpDown1;
	TGroupBox *GBLang;
	TRadioButton *RBENG;
	TRadioButton *RBHR;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TLabel *Label10;
	TButton *BBack;
	TLabel *Label11;
	TDBNavigator *DBNKlub;
	TButton *BSortiraj;
	TEdit *EFilter;
	TCheckBox *CBFilteri;
	TButton *BUcitajKlubovi;
	THash *Hash1;
	TCryptographicLibrary *CLNoviKorisnik;
	TCodec *Codec1;
	TEdit *EAdresa;
	TCodec *CodecRSA;
	TSignatory *Signatory1;
	TEdit *EIBAN;
	TEdit *EIme;
	TEdit *EPrezime;
	TEdit *EUsername;
	TEdit *EPassword;
	TButton *BSpremi;
	TButton *BAzuriraj;
	TEdit *ETemp;
	TEdit *EOib;
	TComboBox *CBZanimanja;
	TButton *Kljucevi;
	THash *HashMD;
	TButton *BTemp;
	void __fastcall BucitajClick(TObject *Sender);
	void __fastcall BPromijeniClick(TObject *Sender);
	void __fastcall BPromjeniOsobeClick(TObject *Sender);
	void __fastcall CBBackgroundClick(TObject *Sender);
	void __fastcall EFontChange(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall BBackClick(TObject *Sender);
	void __fastcall RBENGClick(TObject *Sender);
	void __fastcall RBHRClick(TObject *Sender);
	void __fastcall BSortirajClick(TObject *Sender);
	void __fastcall CBFilteriClick(TObject *Sender);
	void __fastcall BUcitajKluboviClick(TObject *Sender);
	void __fastcall DBGrid1CellClick(TColumn *Column);
	void __fastcall BSpremiClick(TObject *Sender);
	void __fastcall BAzurirajClick(TObject *Sender);
	void __fastcall KljuceviClick(TObject *Sender);
	void __fastcall BTempClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	std::map<String, std::map<String, String>> translation;
	__fastcall TFNoviKorisnik(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFNoviKorisnik *FNoviKorisnik;
//---------------------------------------------------------------------------
#endif
