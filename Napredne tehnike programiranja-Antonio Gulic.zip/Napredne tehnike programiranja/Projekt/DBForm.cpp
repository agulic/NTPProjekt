//---------------------------------------------------------------------------


#pragma hdrstop

#include "DBForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma classgroup "Vcl.Controls.TControl"
#pragma resource "*.dfm"
TDMBaza *DMBaza;
//---------------------------------------------------------------------------
__fastcall TDMBaza::TDMBaza(TComponent* Owner)
	: TDataModule(Owner)
{
}
//---------------------------------------------------------------------------

