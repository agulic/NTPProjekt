
// **************************************** //
//                                        
//            XML Data Binding            
//                                        
//         Generated on: 8.4.2022. 16:13:34 
//       Generated from: Stadioni.xml     
//   Settings stored in: Stadioni.xdb     
//                                        
// **************************************** //

#ifndef   StadioniH
#define   StadioniH

#include <System.hpp>
#include <Xml.Xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <Xml.XMLDoc.hpp>
#include <XMLNodeImp.h>
#include <Xml.xmlutil.hpp>


// Forward Decls 

__interface IXMLStadioniType;
typedef System::DelphiInterface<IXMLStadioniType> _di_IXMLStadioniType;
__interface IXMLStadionType;
typedef System::DelphiInterface<IXMLStadionType> _di_IXMLStadionType;

// IXMLStadioniType 

__interface INTERFACE_UUID("{AD03801A-2E40-42C2-82CB-D58E92C70B85}") IXMLStadioniType : public Xml::Xmlintf::IXMLNodeCollection
{
public:
public:
  // Property Accessors 
  virtual _di_IXMLStadionType __fastcall Get_Stadion(int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLStadionType __fastcall Add() = 0;
  virtual _di_IXMLStadionType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLStadionType Stadion[int Index] = { read=Get_Stadion };/* default */
};

// IXMLStadionType 

__interface INTERFACE_UUID("{906CE8E0-1A3B-4FA0-8B6D-73A567C60B5C}") IXMLStadionType : public Xml::Xmlintf::IXMLNode
{
public:
  // Property Accessors 
  virtual int __fastcall Get_ID() = 0;
  virtual System::UnicodeString __fastcall Get_Naziv() = 0;
  virtual System::UnicodeString __fastcall Get_Adresa() = 0;
  virtual int __fastcall Get_Kapacitet() = 0;
  virtual int __fastcall Get_Cijena() = 0;
  virtual void __fastcall Set_ID(int Value) = 0;
  virtual void __fastcall Set_Naziv(System::UnicodeString Value) = 0;
  virtual void __fastcall Set_Adresa(System::UnicodeString Value) = 0;
  virtual void __fastcall Set_Kapacitet(int Value) = 0;
  virtual void __fastcall Set_Cijena(int Value) = 0;
  // Methods & Properties 
  __property int ID = { read=Get_ID, write=Set_ID };
  __property System::UnicodeString Naziv = { read=Get_Naziv, write=Set_Naziv };
  __property System::UnicodeString Adresa = { read=Get_Adresa, write=Set_Adresa };
  __property int Kapacitet = { read=Get_Kapacitet, write=Set_Kapacitet };
  __property int Cijena = { read=Get_Cijena, write=Set_Cijena };
};

// Forward Decls 

class TXMLStadioniType;
class TXMLStadionType;

// TXMLStadioniType 

class TXMLStadioniType : public Xml::Xmldoc::TXMLNodeCollection, public IXMLStadioniType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLStadioniType 
  virtual _di_IXMLStadionType __fastcall Get_Stadion(int Index);
  virtual _di_IXMLStadionType __fastcall Add();
  virtual _di_IXMLStadionType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};

// TXMLStadionType 

class TXMLStadionType : public Xml::Xmldoc::TXMLNode, public IXMLStadionType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLStadionType 
  virtual int __fastcall Get_ID();
  virtual System::UnicodeString __fastcall Get_Naziv();
  virtual System::UnicodeString __fastcall Get_Adresa();
  virtual int __fastcall Get_Kapacitet();
  virtual int __fastcall Get_Cijena();
  virtual void __fastcall Set_ID(int Value);
  virtual void __fastcall Set_Naziv(System::UnicodeString Value);
  virtual void __fastcall Set_Adresa(System::UnicodeString Value);
  virtual void __fastcall Set_Kapacitet(int Value);
  virtual void __fastcall Set_Cijena(int Value);
};

// Global Functions 

_di_IXMLStadioniType __fastcall GetStadioni(Xml::Xmlintf::_di_IXMLDocument Doc);
_di_IXMLStadioniType __fastcall GetStadioni(Xml::Xmldoc::TXMLDocument *Doc);
_di_IXMLStadioniType __fastcall LoadStadioni(const System::UnicodeString& FileName);
_di_IXMLStadioniType __fastcall  NewStadioni();

#define TargetNamespace ""

#endif