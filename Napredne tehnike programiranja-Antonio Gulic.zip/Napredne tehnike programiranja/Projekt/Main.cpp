//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "Stadioni1.h"
#include <Registry.hpp>
#include "Login.h"
#include "DBForm.h"
#include <jpeg.hpp>
#include<pngimage.hpp>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "frxClass"
#pragma link "frxDBSet"
#pragma link "frxExportBaseDialog"
#pragma link "frxExportImage"
#pragma link "frxExportPDF"
#pragma link "frxExportRTF"
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma resource "*.dfm"
TFMain *FMain;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i = 0; i < Form->ComponentCount; i++) // iterate though all components on the form
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first) // find component by name
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language) // find translation for the target language
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}

//---------------------------------------------------------------------------
__fastcall TFMain::TFMain(TComponent* Owner)
	: TForm(Owner)
{
	translation["Label1"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Ime:"}
		}
	};
		translation["Label2"] =	{
		{
			{"EN", "Last name:"},
			{"HR", "Prezime:"}
		}
	};
		translation["Label3"] =	{
		{
			{"EN", "Adress:"},
			{"HR", "Adresa:"}
		}
	};
		translation["Label4"] =	{
		{
			{"EN", "Name:"},
			{"HR", "Naziv:"}
		}
	};
		translation["Label5"] =	{
		{
			{"EN", "Adress:"},
			{"HR", "Adresa:"}
		}
	};
		translation["Label7"] =	{
		{
			{"EN", "Travel distance:"},
			{"HR", "Udaljenost:"}
		}
	};
		translation["Label8"] =	{
		{
			{"EN", "KM price:"},
			{"HR", "Cijena KM:"}
		}
	};
		translation["Label9"] =	{
		{
			{"EN", "League:"},
			{"HR", "Liga:"}
		}
	};
		translation["Label10"] =	{
		{
			{"EN", "Round:"},
			{"HR", "Kolo:"}
		}
	};
		translation["Label11"] =	{
		{
			{"EN", "Home:"},
			{"HR", "Doma�i:"}
		}
	};
		translation["Label12"] =	{
		{
			{"EN", "Away:"},
			{"HR", "Gosti:"}
		}
	};
		translation["GroupBox1"] =	{
		{
			{"EN", "Basic info"},
			{"HR", "Osnovni podatci"}
		}
	};
		translation["GBStadion"] =	{
		{
			{"EN", "Stadium"},
			{"HR", "Stadion"}
		}
	};
		translation["GBUtakmica"] =	{
		{
			{"EN", "Game"},
			{"HR", "Utakmica"}
		}
	};
		translation["RBGlavniSudac"] =	{
		{
			{"EN", "Referee"},
			{"HR", "Glavni sudac"}
		}
	};
		translation["RBPomocniSudac"] =	{
		{
			{"EN", "Assistant referee"},
			{"HR", "Pomo�ni sudac"}
		}
	};
		translation["RBCetvrtiSudac"] =	{
		{
			{"EN", "Fourth referee"},
			{"HR", "�etvrti sudac"}
		}
	};
		translation["BBack"] =	{
		{
			{"EN", "Back to login"},
			{"HR", "Nazad na prijavu"}
		}
	};
		translation["BUcitajStadion"] =	{
		{
			{"EN", "Load Stadium"},
			{"HR", "U�itaj stadion"}
		}
	};
		translation["BNalog"] =	{
		{
			{"EN", "Show warrant"},
			{"HR", "Poka�i nalog"}
		}
	};
    	translation["CBBackground"] =	{
		{
			{"EN", "Dark Mode"},
			{"HR", "Tamni Na�in"}
		}
	};
	translation["Label6"] =	{
		{
			{"EN", "Font size:"},
			{"HR", "Veli�ina fonta:"}
		}
	};
	translation["BOsvjezi"] =	{
		{
			{"EN", "Refresh"},
			{"HR", "Osvje�i"}
		}
	};
	translation["BGeneriraj"] =	{
		{
			{"EN", "Generate warrant"},
			{"HR", "Generiraj nalog"}
		}
	};
	translation["BPromijeni"] =	{
		{
			{"EN", "Update last warrant"},
			{"HR", "Azuriraj zadnji nalog"}
		}
	};
		translation["Label14"] =	{
		{
			{"EN", "Date:"},
			{"HR", "Datum:"}
		}
	};

}
//---------------------------------------------------------------------------


void __fastcall TFMain::CBBackgroundClick(TObject *Sender)
{
 if(CBBackground->Checked){
  FMain->Color = clGray;

 }
 else{
	  FMain->Color = clBtnFace;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFMain::EFontChange(TObject *Sender)
{
      FMain->Font->Size = EFont->Text.ToInt();
}
//---------------------------------------------------------------------------


void __fastcall TFMain::EPutovanjeClick(TObject *Sender)
{
    EPutovanje->Text = "";
}
//---------------------------------------------------------------------------


void __fastcall TFMain::BUcitajStadionClick(TObject *Sender)
{
	FStadioniPopis->ShowModal();

		EStadionNaziv->Text = FStadioniPopis->ENazivTemp->Text;
        EAdresaStadion->Text = FStadioniPopis->EAdresaTemp->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::FormClose(TObject *Sender, TCloseAction &Action)
{
    TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	ini->WriteInteger("Main Window", "Left", Left);
	ini->WriteInteger("Main Window", "Top", Top);
	ini->WriteInteger("Main Window", "Width", Width);
	ini->WriteInteger("Main Window", "Height", Height);
	if (CBBackground->Checked)
		ini->WriteBool("Main Window", "Dark mode", TRUE);
	else
		ini->WriteBool("Main Window", "Dark mode", FALSE);

	ini->WriteString("Main Window", "Font size", EFont->Text);

	if(RBENG->Checked)
		ini->WriteString("Main Window", "Language", "ENG");
	else
        ini->WriteString("Main Window", "Language", "HR");
    delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::FormCreate(TObject *Sender)
{
	TIniFile* ini = new TIniFile(GetCurrentDir() + "setings.ini");
	Left = ini->ReadInteger("Main Window", "Left", 0);
	Top = ini->ReadInteger("Main Window", "Top", 0);
	Width = ini->ReadInteger("Main Window", "Width", 800);
	Height = ini->ReadInteger("Main Window", "Height", 500);
	if(ini->ReadBool("Main Window", "Dark mode", FALSE))
		CBBackground->Checked = TRUE;
	else
		CBBackground->Checked = FALSE;

	String temp = ini->ReadString("Main Window", "Font size", 12);
	EFont->Text = temp;
    FMain->Font->Size = EFont->Text.ToInt();

	if(ini->ReadString("Main Window", "Language","ENG") == "ENG")
		RBENG->Checked = TRUE;
	else
        RBHR->Checked = TRUE;
	delete ini;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::RBHRClick(TObject *Sender)
{
	translateForm(this, "HR", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFMain::RBENGClick(TObject *Sender)
{
    translateForm(this, "EN", translation);
}
//---------------------------------------------------------------------------

void __fastcall TFMain::BBackClick(TObject *Sender)
{   Eime->Clear();
	Eprezime->Clear();
	Eadresa->Clear();
	EIBAN->Clear();
	EStadionNaziv->Clear();
	EAdresaStadion->Clear();
	EPutovanje->Clear();
	FMain->Close();
	FLogin->Show();
	FLogin->LError->Visible = FALSE;
	DMBaza->ADOGotoviZapisnici->Filtered = FALSE;
}
//---------------------------------------------------------------------------

void __fastcall TFMain::BOsvjeziClick(TObject *Sender)
{
	Eime->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Ime")->AsString;
	Eprezime->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Prezime")->AsString;

	String decodedMessage2;
	String temp;
	temp = DMBaza->ADOSluzbeneOsobe->FieldByName("Adresa")->Text;
	Codec2->Password = "0v0j3jak0duga1k0mpl1c1ranal0z1nkasabr0j3v1maumjest0sl0va";
	Codec2->DecryptString(decodedMessage2, temp, TEncoding::ANSI);

	Eadresa->Text = decodedMessage2;
	EIBAN->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("IBAN")->AsString;

}
//---------------------------------------------------------------------------

void __fastcall TFMain::BGenerirajClick(TObject *Sender)
{

	DMBaza->ADOGotoviZapisnici->FieldByName("ImeSluzbeneOsobe")->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Ime")->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("PrezimeSluzbeneOsobe")->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Prezime")->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("AdresaSluzbeneOsobe")->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("Adresa")->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("IBANSluzbeneOsobe")->Text = DMBaza->ADOSluzbeneOsobe->FieldByName("IBAN")->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("Liga")->Text = CBLiga->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("Kolo")->Text = Ekolo->Text;
	if(RBGlavniSudac->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text = "Glavni Sudac";
	else if(RBPomocniSudac->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text = "Pomocni Sudac";
	else if(RBCetvrtiSudac->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text = "Cetvrti Sudac";
	else if(DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text == "Doktor")
		DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text = "Doktor";
	else if(DMBaza->ADOSluzbeneOsobe->FieldByName("Zanimanje")->Text == "Delegat")
		DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text = "Delegat";

	if(RadioButton1->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("CijenaKM")->Text = 0.67 ;
	else if(RadioButton2->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("CijenaKM")->Text = 1.33;
	else if(RadioButton3->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("CijenaKM")->Text = 1.66;
	else if(RadioButton4->Checked)
		DMBaza->ADOGotoviZapisnici->FieldByName("CijenaKM")->Text = 2.0;

	DMBaza->ADOGotoviZapisnici->FieldByName("Stadion")->Text = EStadionNaziv->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("AdresaStadiona")->Text = EAdresaStadion->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("Udaljenost")->Text = EPutovanje->Text;
	DMBaza->ADOGotoviZapisnici->FieldByName("Datum")->Text = DTPMain->Date;
	DMBaza->ADOGotoviZapisnici->Post();

    BCijena->Click();
}
//---------------------------------------------------------------------------

void __fastcall TFMain::FormActivate(TObject *Sender)
{
	DMBaza->ADOGotoviZapisnici->Append();
	
}
//---------------------------------------------------------------------------


void __fastcall TFMain::BCijenaClick(TObject *Sender)
{
	DMBaza->ADOGotoviZapisnici->Filter = "ID LIKE " + QuotedStr(DMBaza->ADOGotoviZapisnici->FieldByName("ID")->Text);
	DMBaza->ADOGotoviZapisnici->Filtered = TRUE;
	TCPClient->Host = "localhost";
	TCPClient->Connect();
	int liga = CBLiga->Text.Length();
	int duznost = DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text.Length();
	TCPClient->Socket->Write(liga);
	TCPClient->Socket->Write(CBLiga->Text);
	TCPClient->Socket->Write(duznost);
	TCPClient->Socket->Write(DMBaza->ADOGotoviZapisnici->FieldByName("ObavljenaDu�nost")->Text);
	int cijenaDuznosti = TCPClient->Socket->ReadInt32();
	int cijenaPutovanja = DMBaza->ADOGotoviZapisnici->FieldByName("CijenaKM")->Text.ToInt() * DMBaza->ADOGotoviZapisnici->FieldByName("Udaljenost")->Text.ToInt();
	ShowMessage(cijenaDuznosti);
	ShowMessage(cijenaPutovanja);
	TCPClient->Disconnect();

	int ukupnaCijena = cijenaDuznosti + cijenaPutovanja;
	DMBaza->ADOGotoviZapisnici->Edit();
	DMBaza->ADOGotoviZapisnici->FieldByName("UkupnaCijena")->Text = ukupnaCijena;
	DMBaza->ADOGotoviZapisnici->Post();


}
//---------------------------------------------------------------------------

void __fastcall TFMain::BNalogClick(TObject *Sender)
{   //ShowMessage(DMBaza->ADOGotoviZapisnici->FieldByName("ID")->Text);
	DMBaza->ADOGotoviZapisnici->Filter = "ID LIKE " + QuotedStr(DMBaza->ADOGotoviZapisnici->FieldByName("ID")->Text);
	DMBaza->ADOGotoviZapisnici->Filtered = TRUE;
	FRMain->ShowReport();
}
//---------------------------------------------------------------------------

